import React from 'react'
import { Form, Button, Header } from 'semantic-ui-react'
import './formulario.css'

export function Formulario(){

    return(
        <Form unstackable className="FonteForm">
            <Header as="h4">MONTE SEU KIT !</Header>
            <Form.Group widths={2}>
                <Form.Input label="Nome" placeholder="Digite seu Nome"/>
                <Form.Input label="Email" placeholder="Digite seu E-mail"/>
            </Form.Group>

            <Form.Group widths={2}>
                <Form.Input label="Endereço" placeholder="Digite seu Endereço"/>
                <Form.Input label="Celular" placeholder="(99)99999-9999"/>
            </Form.Group>

            <Header as="h4">GummyJay</Header>
            <Form.Group widths={2}>
                <Form.Field label="Sabor Frutas Cítricas" control="input" type="checkbox"/>
                <Form.Field label="Sabor Frutas Vermelhas & Verdes" control="input" type="checkbox"/>
            </Form.Group>

            <Header as="h4">Creme Hidratante</Header>
            <Form.Group widths={2}>
                <Form.Field label="A Base de Babosa" control="input" type="checkbox"/>
                <Form.Field label="A Base de Camomilla" control="input" type="checkbox"/>
                <Form.Field label="A Base de Coco" control="input" type="checkbox"/>
            </Form.Group>

            <Header as="h4">Shampo e Condicionador</Header>
            <Form.Group widths={2}>
                <Form.Field label="Restauração Total" control="input" type="checkbox"/>
                <Form.Field label="Limpeza Profunda" control="input" type="checkbox"/>
                <Form.Field label="Anti-Queda" control="input" type="checkbox"/>
                <Form.Field label="Finos e ressecados" control="input" type="checkbox"/>
            </Form.Group>

            <Header as="h4">Skin Care</Header>
            <Form.Group widths={2}>
                <Form.Field label="" control="input" type="checkbox"/>
                <Form.Field label="Pele Oleosa" control="input" type="checkbox"/>
                <Form.Field label="Anti-Acne" control="input" type="checkbox"/>
                <Form.Field label="Pele Seca" control="input" type="checkbox"/>
            </Form.Group>

            <Form.Checkbox label="Aceito os termos e condições"/>
            <Button type="submit">ENVIAR</Button>

        </Form>
    )
} 