import { Header,Container } from "semantic-ui-react";
import './cabecalho.css'

export function Cabecalho(){

    return(
        <Container fluid>
            <Header as="h2">Pizzaria Carioca</Header>
            <p className = "FormatarFonte">
            De uma pizzaria local no estado do Rio de Janeiro, em 2022, à maior rede de pizzarias do Brasil: a Pizzaria Carioca está presente hoje em várias regiões, com mais de 16 lojas. A primeira loja, foi inaugurada no Rio de Janeiro, no bairro de Campo Grande. Ao longo desse ano, investimos em tecnologia e delivery para melhorar a experiência dos amantes de pizza. Até 2023 vamos investir R$ 2 milhões para dobrar de tamanho e chegar a 32 unidades.
        </p>
        <p className = "FormatarFonte">
            Sob gestão de Alessandro Vieira, a Pizzaria Carioca preserva o mais alto padrão de qualidade para o produto e o serviço. Nosso processo é artesanal, com massas frescas que passam por 48 horas de fermentação. Este é um dos nossos principais atributos: abrimos cada uma de nossas pizzas à mão. Nossos fornos também são os mais quentes do mercado para que as pizzas cheguem quentinhas à casa dos nossos clientes.
        </p>
        <p className = "FormatarFonte">
            A gente ama o que faz e sabe que o brasileiro é apaixonado por pizzas. Por isso, nossa missão é vender pizza com mais diversão. A Pizzaria Carioca é uma empresa que integra o seleto grupo das melhores empresas para se trabalhar, segundo o ranking Great Place to Work (GPTW), consultoria que chancela mundialmente os melhores ambientes de trabalho, a partir das práticas do negócio e da opinião dos funcionários dessas empresas.
        </p>

        </Container>
    )
}