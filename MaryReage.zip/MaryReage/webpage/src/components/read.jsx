import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Table, Button, TableRow } from 'semantic-ui-react';

export default function Read() {
    const [APIData, setAPIData] = useState([]);
    useEffect(() => {
        axios.get(`https://63780b0a0992902a2515b79f.mockapi.io/compras`)
            .then((response) => {
                console.log(response.data)
                setAPIData(response.data)
            })
    }, []);

    

    const getData = () => {
        axios.get(`https://63780b0a0992902a2515b79f.mockapi.io/compras`)
            .then((getData) => {
                setAPIData(getData.data)
            })
    }

    const onDelete = (id) => {
        axios.delete(`https://63780b0a0992902a2515b79f.mockapi.io/compras/${id}`)
        .then(() => {
            getData();
        })
    }

    const confirmar = () =>{
       alert('Compra Confirmada')
    }

    return (
        <div>
            <Table singleLine>
                <Table.Header>
                    <Table.Row>
                        <Table.HeaderCell>Produto</Table.HeaderCell>
                        <Table.HeaderCell>Descrição</Table.HeaderCell>
                        <Table.HeaderCell>Quantidade</Table.HeaderCell>
                        <Table.HeaderCell>Valor</Table.HeaderCell>
                        <Table.HeaderCell>SubTotal</Table.HeaderCell>
                        <Table.HeaderCell>Ação</Table.HeaderCell>
                    </Table.Row>
                </Table.Header>

                <Table.Body>
                    {APIData.map((
                        
                    ) => {
                        return (
                            <Table.Row className='tabela'>
                                <Table.Cell>{data.Nome}</Table.Cell>
                                <Table.Cell>{data.Descricao}</Table.Cell>
                                <Table.Cell>{data.Quantidade}</Table.Cell>
                                <Table.Cell>{data.Valor}</Table.Cell>
                                <Table.Cell>{data.Subtotal}</Table.Cell>
                                <Table.Cell>
                                    <Button onClick={() => onDelete(data.id)}>Remover</Button>
                                </Table.Cell>
                            </Table.Row>
                        )
                    })}
                </Table.Body>
            </Table>
            <Button onClick={() => confirmar()}>Confirmar Compra</Button>
        </div>
    )
}