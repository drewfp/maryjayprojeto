import React from 'react'
import Iframe from 'react-iframe'
import { Header } from 'semantic-ui-react'
import './mapa.css'

export function Mapa(){

    return(
        <div>
            <Header as="h3" className="titulo">Localização</Header>
            <Iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3675.3563529237713!2d-43.5610351854006!3d-22.90022344339332!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x9be15839e68c4f%3A0x588a284ae162bc38!2sSenac%20Campo%20Grande!5e0!3m2!1spt-BR!2sbr!4v1670884487308!5m2!1spt-BR!2sbr" width="350" height="500" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"/>
        </div>
    )
}