import React, { useState } from 'react';
import { Button, Form } from 'semantic-ui-react'
import axios from 'axios';

export default function Create() {
    const [Nome, setNome] = useState('');
    const [Descricao, setDescricao] = useState('');
    const [Quantidade, setQuantidade] = useState('');
    const [Valor, setValor] = useState('');
    const Subtotal = (Quantidade*Valor);

    const postData = () => {
        axios.post(`https://63780b0a0992902a2515b79f.mockapi.io/compras`, {
            Nome,
            Descricao,
            Quantidade,
            Valor,
            Subtotal
        })
        alert("Dados enviados com sucesso")
        window.location.reload()
    }

    return (
        <div>
            <Form className="create-form">
                <Form.Field>
                    <label>Nome do Produto</label>
                    <input placeholder='Nome do Produto' onChange={(e) => setNome(e.target.value)}/>
                </Form.Field>
                <Form.Field>
                    <label>Descrição do Produto</label>
                    <input placeholder='Descrição do Produto' onChange={(e) => setDescricao(e.target.value)}/>
                </Form.Field>
                <Form.Field>
                    <label>Quantidade do Produto</label>
                    <input placeholder='Quantidade do Produto' onChange={(e) => setQuantidade(e.target.value)}/>
                </Form.Field>
                <Form.Field>
                    <label>Valor do Produto</label>
                    <input placeholder='Valor do Produto' onChange={(e) => setValor(e.target.value)}/>
                </Form.Field>
                <Button onClick={postData} type='submit'>ENVIAR</Button>
            </Form>
        </div>
    )
}