import React from 'react'
import { Grid } from 'semantic-ui-react'
import { Cabecalho } from './components/cabecalho/cabecalho.jsx'
import { Formulario } from './components/formulario/formulario.jsx'
import { Mapa } from './components/mapa/mapa.jsx'
import './App.css'
import pizza01 from './assets/pizza01.jpg'
import pizza02 from './assets/pizza02.jpg'
import pizza03 from './assets/pizza03.jpg'
import pizza04 from './assets/pizza04.jpg'


function App() {

  return (
    <Grid>

      <Grid.Row>
        <Grid.Column width={20}>
          <Cabecalho/>
        </Grid.Column>
      </Grid.Row>

      <Grid.Row>
        <Grid.Column width={4}>
         <img src = {pizza01} className = "logo react"/>
        </Grid.Column>

        <Grid.Column width={4}>
        <img src = {pizza02} className = "logo react"/>
        </Grid.Column>

        <Grid.Column width={4}>
        <img src = {pizza03} className = "logo react"/>
        </Grid.Column>

        <Grid.Column width={4}>
        <img src = {pizza04} className = "logo react"/>
        </Grid.Column>
      </Grid.Row>

      <Grid.Row>
        <Grid.Column width={9} textAlign={'center'}>
          <Formulario/>
        </Grid.Column>

        

      
        

      
      </Grid.Row>


    


    
    </Grid>
  )
}

export default App
